# Student–Course Many-to-Many API (Spring Boot + H2)

Java 17 / Spring Boot 3 example for STS. Student owns the `student_course` join table. The inverse collection uses `mappedBy = "courses"`; Jackson serializes courses under a student and suppresses the back-reference to students.

## Open and run in STS

1. Extract/open the `student-course-api` folder in Spring Tool Suite as an **Existing Maven Project**.
2. Ensure STS is configured for JDK 17, then run `StudentCourseApplication.java` as **Spring Boot App**.
3. The API runs at `http://localhost:8080`. H2 is in-memory, so its data resets when the application stops.

H2 console: `http://localhost:8080/h2-console` with JDBC URL `jdbc:h2:mem:studentcoursedb`, username `sa`, and an empty password.

## Request format

Create courses first, then refer to existing courses by `courseIds`. For example:

```json
{ "studentName": "Priya", "courseIds": [1, 2] }
```

This API deliberately accepts IDs instead of nested `{"courseId":1}` entity objects, so request JSON cannot accidentally be treated as new or detached Course entities. `PUT /api/students/{id}` replaces the complete course set; omit `courseIds` or pass `[]` to clear it. A provided `studentName` also updates the name.

## Endpoints

| Method | Endpoint | Purpose |
|---|---|---|
| POST | `/api/courses` | Create course: `{ "courseName": "Advance Java" }` |
| POST | `/api/students` | Create student: `{ "studentName": "Priya", "courseIds": [1] }` |
| GET | `/api/students/{id}` | Student with enrolled courses |
| POST | `/api/students/{id}/enroll/{courseId}` | Add one existing course (returns updated student) |
| PUT | `/api/students/{id}` | Replace name if provided and replace all course links |
| DELETE | `/api/students/{studentId}/unenroll/{courseId}` | Remove only the link; 204 response |
| GET | `/api/courses/{id}/students` | Students enrolled in a course |
| PUT | `/api/courses/{id}` | Update course name |
| DELETE | `/api/courses/{id}` | Remove links and delete course; 204 response |

Missing student/course IDs return 404; invalid names return 400.

## Suggested Postman sequence

1. `POST http://localhost:8080/api/courses` body `{"courseName":"Advance Java"}`
2. Create another course with `POST /api/courses`, e.g. `{"courseName":"Database Systems"}`
3. `POST /api/students` body `{"studentName":"Priya","courseIds":[1]}`
4. `POST /api/students/1/enroll/2`
5. `GET /api/students/1`, then `GET /api/courses/1/students`
6. `PUT /api/courses/1` body `{"courseName":"Advance Java (Spring Boot)"}`
7. `PUT /api/students/1` body `{"studentName":"Priya","courseIds":[1]}`
8. `DELETE /api/students/1/unenroll/1`, then optionally `DELETE /api/courses/1`

All endpoints above are also included in `postman/Student-Course-API.postman_collection.json`.
