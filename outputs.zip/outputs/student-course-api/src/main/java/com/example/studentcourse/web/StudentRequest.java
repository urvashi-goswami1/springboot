package com.example.studentcourse.web;

import java.util.Set;

public record StudentRequest(String studentName, Set<Integer> courseIds) { }
