package com.example.studentcourse.controller;

import com.example.studentcourse.entity.Course;
import com.example.studentcourse.entity.Student;
import com.example.studentcourse.repository.CourseRepository;
import com.example.studentcourse.web.CourseRequest;
import jakarta.transaction.Transactional;
import java.util.List;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

@RestController
@RequestMapping("/api/courses")
public class CourseRestController {
    private final CourseRepository courses;
    public CourseRestController(CourseRepository courses) { this.courses = courses; }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public Course create(@RequestBody CourseRequest request) {
        Course course = new Course();
        course.setCourseName(requireName(request.courseName()));
        return courses.save(course);
    }

    @GetMapping("/{id}/students")
    @Transactional
    public List<Student> students(@PathVariable Integer id) {
        Course course = findCourse(id);
        return List.copyOf(course.getStudents());
    }

    @PutMapping("/{id}")
    @Transactional
    public Course update(@PathVariable Integer id, @RequestBody CourseRequest request) {
        Course course = findCourse(id);
        course.setCourseName(requireName(request.courseName()));
        return courses.save(course);
    }

    @DeleteMapping("/{id}")
    @Transactional
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Integer id) {
        Course course = findCourse(id);
        // Remove inverse-side references before deleting the course so join rows are removed cleanly.
        for (Student student : List.copyOf(course.getStudents())) {
            student.getCourses().removeIf(c -> c.getCourseId().equals(id));
        }
        course.getStudents().clear();
        courses.delete(course);
    }

    private Course findCourse(Integer id) {
        return courses.findById(id).orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Course " + id + " not found"));
    }
    private String requireName(String name) {
        if (name == null || name.isBlank()) throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "courseName is required");
        return name.trim();
    }
}
