package com.example.studentcourse.web;

public record CourseRequest(String courseName) { }
