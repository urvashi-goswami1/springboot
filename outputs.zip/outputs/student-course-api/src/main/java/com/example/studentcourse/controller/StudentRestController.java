package com.example.studentcourse.controller;

import com.example.studentcourse.entity.Course;
import com.example.studentcourse.entity.Student;
import com.example.studentcourse.repository.CourseRepository;
import com.example.studentcourse.repository.StudentRepository;
import com.example.studentcourse.web.StudentRequest;
import jakarta.transaction.Transactional;
import java.util.LinkedHashSet;
import java.util.Set;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

@RestController
@RequestMapping("/api/students")
public class StudentRestController {
    private final StudentRepository students;
    private final CourseRepository courses;
    public StudentRestController(StudentRepository students, CourseRepository courses) {
        this.students = students;
        this.courses = courses;
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    @Transactional
    public Student create(@RequestBody StudentRequest request) {
        Student student = new Student();
        student.setStudentName(requireName(request.studentName()));
        student.setCourses(resolveCourses(request.courseIds()));
        return students.save(student);
    }

    @GetMapping("/{id}")
    @Transactional
    public Student get(@PathVariable Integer id) {
        Student student = findStudent(id);
        // Initialize the lazy collection while the transaction is open; JSON is written after this method returns.
        student.getCourses().size();
        return student;
    }

    @PostMapping("/{id}/enroll/{courseId}")
    @Transactional
    public Student enroll(@PathVariable Integer id, @PathVariable Integer courseId) {
        Student student = findStudent(id);
        Course course = findCourse(courseId);
        student.getCourses().add(course);
        return students.save(student);
    }

    @PutMapping("/{id}")
    @Transactional
    public Student replace(@PathVariable Integer id, @RequestBody StudentRequest request) {
        Student student = findStudent(id);
        if (request.studentName() != null) student.setStudentName(requireName(request.studentName()));
        student.setCourses(resolveCourses(request.courseIds()));
        return students.save(student);
    }

    @DeleteMapping("/{studentId}/unenroll/{courseId}")
    @Transactional
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void unenroll(@PathVariable Integer studentId, @PathVariable Integer courseId) {
        Student student = findStudent(studentId);
        boolean removed = student.getCourses().removeIf(course -> course.getCourseId().equals(courseId));
        if (!removed) throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Student is not enrolled in course " + courseId);
        students.save(student);
    }

    private Student findStudent(Integer id) {
        return students.findById(id).orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Student " + id + " not found"));
    }
    private Course findCourse(Integer id) {
        return courses.findById(id).orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Course " + id + " not found"));
    }
    private Set<Course> resolveCourses(Set<Integer> ids) {
        Set<Course> result = new LinkedHashSet<>();
        if (ids == null) return result;
        for (Integer id : ids) {
            if (id == null) throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "courseIds cannot contain null");
            result.add(findCourse(id));
        }
        return result;
    }
    private String requireName(String name) {
        if (name == null || name.isBlank()) throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "studentName is required");
        return name.trim();
    }
}
